<?php
include(dirname(__FILE__).'/single.php');
?>