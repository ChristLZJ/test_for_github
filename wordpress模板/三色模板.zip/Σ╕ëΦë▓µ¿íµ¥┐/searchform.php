<form method="get" id="searchform" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
<input type="text" name="s" id="s" placeholder="Your Keywords" >
            <input type="submit"  value="">
</form>